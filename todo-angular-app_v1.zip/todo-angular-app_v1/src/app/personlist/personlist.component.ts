import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Person } from '../entity/person';
import { PersonserviceService } from '../service/personservice.service';

@Component({
  selector: 'app-personlist',
  templateUrl: './personlist.component.html',
  styleUrls: ['./personlist.component.css']
})
export class PersonlistComponent implements OnInit {

  personlist=[new Person(0,'','','',0,new Date)];
  constructor(private service:PersonserviceService,private router:Router) { }

  ngOnInit() {

    this.refreshPage();
  }

  deletePerson(id:number)
  {
    console.log(id);
    this.service.deletePerson(id).subscribe(
      response=>{
        console.log(id);
        console.log(response);
        this.refreshPage();
      });
  }

  updatePerson(id:number)
  {

  }

  refreshPage()
  {
    this.service.personList().subscribe(
      response=>{
        console.log('Riyaz.....');
        this.personlist=response;
        console.log(response);
      } );
  }

}
