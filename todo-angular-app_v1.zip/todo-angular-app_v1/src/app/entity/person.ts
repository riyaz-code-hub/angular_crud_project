export class Person {

    constructor(
        public id:number,
        public fname:string,
        public lname:string,
        public mail:string,
        public mobile:number,
        public dob:Date
        ){}
    

    
}
