import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Person } from '../entity/person';

@Injectable({
  providedIn: 'root'
})
export class PersonserviceService {

  constructor(private http:HttpClient) { }

personList()
{
  /*13.233.136.13 */
  return this.http.get<Person[]>(`http://15.207.223.55:8181/person/all`);
}

deletePerson(id:number)
  { 
    
    return this.http.delete(`http://15.207.223.55:8181/person/id/${id}`);
    
  }

  retrievePersonById(id:number)
  { 
    
    return this.http.get<Person>(`http://15.207.223.55:8181/person/id/${id}`);
    
  }
  
  createPerson(person:Person)
  { 
    
    return this.http.post(`http://15.207.223.55:8181/person`,person);
    
  }


}
