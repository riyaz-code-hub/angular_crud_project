import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PersonDetailComponent } from './person-detail/person-detail.component';
import { PersonlistComponent } from './personlist/personlist.component';

const routes: Routes = [{path:'personlist',component: PersonlistComponent},
{path:'addPerson',component:PersonDetailComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
