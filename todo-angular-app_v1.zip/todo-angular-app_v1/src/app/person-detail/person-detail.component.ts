import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Person } from '../entity/person';
import { PersonserviceService } from '../service/personservice.service';

@Component({
  selector: 'app-person-detail',
  templateUrl: './person-detail.component.html',
  styleUrls: ['./person-detail.component.css']
})
export class PersonDetailComponent implements OnInit {

  person=new Person(0,'','','',0,new Date);

  constructor(private service:PersonserviceService,private router:Router) { }

  ngOnInit(): void {
  }


  savePerson()
  {
    console.log(this.person);
    
    this.service.createPerson(this.person).subscribe(
      data=>{
        console.log('Hi....');
        console.log(data);
        this.router.navigate(['personlist']); 
        console.log('Hello...');       
      }
    );
    }


}
